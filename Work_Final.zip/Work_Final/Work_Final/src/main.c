#include <asf.h>
#include <stdlib.h>
#include "pt.h"

#define OLED1_BUTTON1	EXT1_PIN_9
#define OLED1_BUTTON2	EXT1_PIN_3
#define OLED1_BUTTON3	EXT1_PIN_4

int protothread_decode(struct pt *pt, int num );

char el1[] = "Lampada   ";
char el2[] = "Televisao ";
char el3[] = "Geladeira ";
char el4[] = "Chuveiro  ";
char el5[] = "Computador";

char vet[] = "Ligados:   "; //vet[9],vet[10]
char vet2[] = "Gasto de       kW/h"; // vet[9],vet[10],vet[11],vet[12],vet[13]

int cont = 0;
char aux[2];

int gasto;
char aux2[5];

int val = 17;
int cont2 = 0;

int flag;

struct port_config config_porta;

struct pt pt1;

int main(void)
{
	int op;
	
	system_init();
	gfx_mono_init();
	PT_INIT(&pt1);
	
	port_get_config_defaults(&config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON1, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON2, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON3, &config_porta);
	
	gfx_mono_draw_string(el1 ,0,0, &sysfont);

	while(1){
		if (!port_pin_get_input_level(OLED1_BUTTON1)){
			op = 1;
			flag = 1;
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON2)){
			op = 2;
			flag = 1;
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON3)){
			op = 3;
			flag = 3;
		}
		else{

		}
		protothread_decode(&pt1, op);
		gfx_mono_draw_string(vet ,0,10, &sysfont);
		gfx_mono_draw_string(vet2, 0,20, &sysfont);
	}
}

int protothread_decode(struct pt *pt, int num){
	PT_BEGIN(pt);
	
	while(1){
		flag = 1;
		PT_WAIT_UNTIL(pt, flag != 0);
		
		for(;;){
			if(num == 1){
				cont = cont + 1;
				if(cont < 10){
					itoa(cont, &aux, 10);
					vet[9] = 0x30;
					vet[10] = aux[0];
				}
				else{
					itoa(cont, &aux, 10);
					vet[9] = aux[0];
					vet[10] = aux[1];
				}
			}
			else if(num == 2){
				if(cont > 0){
					cont = cont - 1;
					if(cont < 10){
						itoa(cont, &aux, 10);
						vet[9] = 0x30;
						vet[10] = aux[0];
					}
					else{
						itoa(cont, &aux, 10);
						vet[9] = aux[0];
						vet[10] = aux[1];
					}
				}
			}
			else if(num == 3){
				cont2 = cont2 + 1;
				
				switch(cont2){
					case 0:
						val = 17;
						gfx_mono_draw_string(el1 ,0,0, &sysfont);
						break;
					
					case 1:
						val = 68;
						gfx_mono_draw_string(el2 ,0,00, &sysfont);
						break;
						
					case 2:
						val = 48;
						gfx_mono_draw_string(el3 ,0,00, &sysfont);
						break;
					
					case 3:
						val = 3456;
						gfx_mono_draw_string(el4 ,0,00, &sysfont);
						break;
						
					case 4:
						val = 45;
						gfx_mono_draw_string(el5 ,0,00, &sysfont);
						cont2 = -1;
						break;

				}
				
			}
		
			gasto = cont * val;
			if(gasto < 10){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = 0x30;
				vet2[11] = 0x30;
				vet2[12] = 0x30;
				vet2[13] = aux2[0];
			}
			else if(gasto < 100){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = 0x30;
				vet2[11] = 0x30;
				vet2[12] = aux2[0];
				vet2[13] = aux2[1];
			}
			else if(gasto < 1000){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = 0x30;
				vet2[11] = aux2[0];
				vet2[12] = aux2[1];
				vet2[13] = aux2[2];
			}
			else if(gasto < 10000){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = aux2[0];
				vet2[11] = aux2[1];
				vet2[12] = aux2[2];
				vet2[13] = aux2[3];
			}
			else{
				itoa(gasto, &aux2, 10);
				vet2[9] = aux2[0];
				vet2[10] = aux2[1];
				vet2[11] = aux2[2];
				vet2[12] = aux2[3];
				vet2[13] = aux2[4];
			}
			flag = 0;
			PT_WAIT_UNTIL(pt, flag != 0);
		}
	}
	PT_END(pt);
}