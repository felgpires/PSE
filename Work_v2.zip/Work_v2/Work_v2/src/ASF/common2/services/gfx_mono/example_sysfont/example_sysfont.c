
#include <asf.h>
#include <stdlib.h>
#include "pt.h"

#define OLED1_BUTTON1	EXT1_PIN_9
#define OLED1_BUTTON2	EXT1_PIN_3
#define OLED1_BUTTON3	EXT1_PIN_4

//char vet[8] = {'N', 'U', 'M', 'E', 'R', 'O', ':'};
char vet[] = "Eletron. Ligados:  ";
char vet2[] = "Gasto de     kW/h";

int cont = 0;
char aux[2];

int gasto;
char aux2[3];

struct port_config config_porta;

int main(void)
{

	system_init();
	gfx_mono_init();
	
	port_get_config_defaults(&config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON1, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON2, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON3, &config_porta);
	
	//gfx_mono_draw_string("Come�o" ,0,0, &sysfont);

	while (true) {
		if (!port_pin_get_input_level(OLED1_BUTTON1)) {
			cont = cont + 1;
			if(cont < 10){
				itoa(cont, &aux, 10);
				vet[17] = 0x30;
				vet[18] = aux[0];
			}
			else{
				itoa(cont, &aux, 10);
				vet[17] = aux[0];
				vet[18] = aux[1];
			}
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON2)){
			if(cont > 0){
				cont = cont - 1;
				if(cont < 10){
					itoa(cont, &aux, 10);
					vet[17] = 0x30;
					vet[18] = aux[0];
				}
				else{
					itoa(cont, &aux, 10);
					vet[17] = aux[0];
					vet[18] = aux[1];
				}				
			}
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON3)){
			gasto = cont * 10;
			if(gasto < 10){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = 0x30;
				vet2[11] = aux2[0];
			}
			else if(gasto < 100){
				itoa(gasto, &aux2, 10);
				vet2[9] = 0x30;
				vet2[10] = aux2[0];
				vet2[11] = aux2[1];
			}
			else{
				itoa(gasto, &aux2, 10);
				vet2[9] = aux2[0];
				vet2[10] = aux2[1];
				vet2[11] = aux2[2];
			}
		}
		else{
			//gfx_mono_draw_string("TOMA NO CU",0,0, &sysfont);
		}
		
		gfx_mono_draw_string(vet ,0,0, &sysfont);
		gfx_mono_draw_string(vet2, 0, 15, &sysfont);
	}
}


/*
	while (true) {
		if (++start_line_address%8 == 0) {
			scroll = 1;
			gfx_mono_draw_string(string[line%LINES],0, ((line)%8)*8, &sysfont);
			line++;
			} else if (start_line_address % 7 != 0) {
			delay_ms(100);
		}

		if ( scroll != 0 ) {
			ssd1306_set_display_start_line_address(start_line_address-8);
			} else {
			gfx_mono_draw_string(string[line%LINES],0, ((line)%8)*8, &sysfont);
			line++;
		}
	}
*/