
#include <asf.h>
#include <stdlib.h>
#include "pt.h"

#define OLED1_BUTTON1	EXT1_PIN_9
#define OLED1_BUTTON2	EXT1_PIN_3
#define OLED1_BUTTON3	EXT1_PIN_4

int protothread_decode(struct pt *pt, int num );

char vet[] = "Eletron. Ligados:  ";
char vet2[] = "Gasto de     kW/h";

int cont = 0;
char aux[2];

int gasto;
char aux2[3];

int flag;

struct port_config config_porta;

struct pt pt1;

int main(void)
{
	int op;
	
	system_init();
	gfx_mono_init();
	PT_INIT(&pt1);
	
	port_get_config_defaults(&config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON1, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON2, &config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON3, &config_porta);

	while(1){
		if (!port_pin_get_input_level(OLED1_BUTTON1)){
			op = 1;
			flag = 1;
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON2)){
			op = 2;
			flag = 1;
		}
		else if(!port_pin_get_input_level(OLED1_BUTTON3)){
			op = 3;
			flag = 3;
		}
		else{

		}
		protothread_decode(&pt1, op);
		gfx_mono_draw_string(vet ,0,0, &sysfont);
		gfx_mono_draw_string(vet2, 0, 15, &sysfont);
	}
}

int protothread_decode(struct pt *pt, int num){
	PT_BEGIN(pt);
	
	while(1){
		flag = 1;
		PT_WAIT_UNTIL(pt, flag != 0);
		
		for(;;){
			if(num == 1){
				cont = cont + 1;
				if(cont < 10){
					itoa(cont, &aux, 10);
					vet[17] = 0x30;
					vet[18] = aux[0];
				}
				else{
					itoa(cont, &aux, 10);
					vet[17] = aux[0];
					vet[18] = aux[1];
				}
			}
			else if(num == 2){
				if(cont > 0){
					cont = cont - 1;
					if(cont < 10){
						itoa(cont, &aux, 10);
						vet[17] = 0x30;
						vet[18] = aux[0];
					}
					else{
						itoa(cont, &aux, 10);
						vet[17] = aux[0];
						vet[18] = aux[1];
					}
				}
			}
			else if(num == 3){
				gasto = cont * 6;
				if(gasto < 10){
					itoa(gasto, &aux2, 10);
					vet2[9] = 0x30;
					vet2[10] = 0x30;
					vet2[11] = aux2[0];
				}
				else if(gasto < 100){
					itoa(gasto, &aux2, 10);
					vet2[9] = 0x30;
					vet2[10] = aux2[0];
					vet2[11] = aux2[1];
				}
				else{
					itoa(gasto, &aux2, 10);
					vet2[9] = aux2[0];
					vet2[10] = aux2[1];
					vet2[11] = aux2[2];
				}
			}
			flag = 0;
			PT_WAIT_UNTIL(pt, flag != 0);
		}
	}
	PT_END(pt);
}