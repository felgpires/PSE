#include <asf.h>

#define OLED1_BUTTON1	EXT1_PIN_9
#define OLED1_BUTTON2	EXT1_PIN_3
#define OLED1_BUTTON3	EXT1_PIN_4

#define OLED1_LED1	EXT1_PIN_7 
#define OLED1_LED2	EXT1_PIN_8
#define OLED1_LED3	EXT1_PIN_6

struct port_config config_porta;

int main (void)
{
	system_init();
	
	port_get_config_defaults(&config_porta);
	
	config_porta.direction  = PORT_PIN_DIR_INPUT;
	config_porta.input_pull = PORT_PIN_PULL_UP;
	port_pin_set_config(OLED1_BUTTON1, &config_porta);
	config_porta.direction = PORT_PIN_DIR_OUTPUT;
	port_pin_set_config(OLED1_LED1, &config_porta);
	

	/* Insert application code here, after the board has been initialized. */

	/* This skeleton code simply sets the LED to the state of the button. */
	while (1) {
		/* Is button pressed? */
		if (port_pin_get_input_level(OLED1_BUTTON1)) {
			/* Yes, so turn LED on. */
			port_pin_set_output_level(OLED1_LED1, true);
		} else {
			/* No, so turn LED off. */
			//port_pin_set_output_level(LED_0_PIN, !LED_0_ACTIVE);
			port_pin_set_output_level(OLED1_LED1, false);
		}
	}
}
